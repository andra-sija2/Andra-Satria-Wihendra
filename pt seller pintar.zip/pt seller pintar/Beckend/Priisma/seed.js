const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  const hashedPassword = await bcrypt.hash('password123', 10);

  const user = await prisma.user.create({
    data: {
      name: 'Budi',
      email: 'budi@example.com',
      password: hashedPassword,
      merchants: {
        create: [
          {
            name: 'BudiKemeja',
            products: {
              create: {
                name: 'Kaos Polos',
                variants: {
                  create: [
                    { color: 'Putih', size: 'M', sku: 'KP-PUTIH-M', stock: 10 },
                    { color: 'Putih', size: 'L', sku: 'KP-PUTIH-L', stock: 12 },
                    { color: 'Hitam', size: 'M', sku: 'KP-HITAM-M', stock: 8 },
                    { color: 'Hitam', size: 'L', sku: 'KP-HITAM-L', stock: 7 }
                  ],
                },
              },
            },
          },
          {
            name: 'BudiSport',
            products: {
              create: {
                name: 'Bola Futsal Premium',
                variants: {
                  create: {
                    color: null,
                    size: null,
                    sku: 'BOLA-FUTSAL-1',
                    stock: 15,
                  },
                },
              },
            },
          },
        ],
      },
    },
  });

  console.log('Seeded user:', user.email);
}

main()
  .catch((e) => console.error(e))
  .finally(async () => await prisma.$disconnect());
