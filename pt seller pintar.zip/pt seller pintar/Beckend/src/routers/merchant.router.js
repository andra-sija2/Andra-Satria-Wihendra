const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const { getMerchantsByUser } = require('../controllers/merchant.controller');

router.get('/', auth, getMerchantsByUser);

module.exports = router;
