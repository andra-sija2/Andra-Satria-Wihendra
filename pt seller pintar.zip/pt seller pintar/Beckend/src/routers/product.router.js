const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const { addProduct, getProductsByMerchant } = require('../controllers/product.controller');

router.post('/', auth, addProduct);
router.get('/:merchantId', auth, getProductsByMerchant);

module.exports = router;
