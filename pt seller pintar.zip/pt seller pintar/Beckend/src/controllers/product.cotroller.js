const prisma = require('../prisma');
const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');
const auth = require('../middleware/authMiddleware');

router.get('/:merchantId', auth, productController.getProductsByMerchant);

router.post('/', auth, productController.createProduct);

module.exports = router;

exports.getProductsByMerchant = async (req, res) => {
  try {
    const merchantId = parseInt(req.params.merchantId);
    const products = await prisma.product.findMany({
      where: { merchantId },
      include: { variants: true }
    });
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: 'Gagal mengambil produk' });
  }
};

exports.createProduct = async (req, res) => {
  try {
    const { name, merchantId, variants } = req.body;

    const product = await prisma.product.create({
      data: {
        name,
        merchant: { connect: { id: merchantId } },
        variants: {
          create: variants.map(v => ({
            color: v.color || null,
            size: v.size || null,
            sku: v.sku,
            stock: parseInt(v.stock)
          }))
        }
      }
    });

    res.status(201).json(product);
  } catch (error) {
    res.status(500).json({ error: 'Gagal menambahkan produk', detail: error.message });
  }
};
