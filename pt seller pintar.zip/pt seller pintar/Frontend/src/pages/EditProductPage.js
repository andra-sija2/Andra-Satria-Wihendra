import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../api/axios';
import { useAuth } from '../auth/AuthContext';

export default function EditProductPage() {
  const { merchantId, productId } = useParams();
  const { token } = useAuth();
  const navigate = useNavigate();

  const [product, setProduct] = useState(null);
  const [form, setForm] = useState({
    name: '',
    description: '',
    colors: '',
    sizes: '',
    stock: '',
    skuPrefix: '',
  });

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const res = await api.get(`/products/${merchantId}/${productId}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        setProduct(res.data);

        // Parse variants
        const colors = [...new Set(res.data.variants.map(v => v.color).filter(Boolean))].join(',');
        const sizes = [...new Set(res.data.variants.map(v => v.size).filter(Boolean))].join(',');
        setForm({
          name: res.data.name,
          description: res.data.description,
          colors,
          sizes,
          stock: res.data.variants[0]?.stock || '',
          skuPrefix: res.data.variants[0]?.sku.split('-')[0] || '',
        });
      } catch (err) {
        console.error(err);
      }
    };
    fetchProduct();
  }, [merchantId, productId, token]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const colorArr = form.colors ? form.colors.split(',').map(c => c.trim()) : [];
    const sizeArr = form.sizes ? form.sizes.split(',').map(s => s.trim()) : [];

    const variants = [];

    if (colorArr.length || sizeArr.length) {
      let index = 1;
      for (const color of colorArr.length ? colorArr : [null]) {
        for (const size of sizeArr.length ? sizeArr : [null]) {
          variants.push({
            color,
            size,
            stock: parseInt(form.stock),
            sku: `${form.skuPrefix}-${index}`,
          });
          index++;
        }
      }
    }

    const payload = {
      name: form.name,
      description: form.description,
      variants,
    };

    try {
      await api.put(`/products/${merchantId}/${productId}`, payload, {
        headers: { Authorization: `Bearer ${token}` },
      });
      navigate(`/merchant/${merchantId}/products`);
    } catch (err) {
      console.error(err);
      alert('Gagal mengedit produk');
    }
  };

  if (!product) return <div>Loading...</div>;

  return (
    <div className="max-w-xl mx-auto mt-10 p-6 shadow bg-white rounded">
      <h2 className="text-xl font-bold mb-4">Edit Produk</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input name="name" placeholder="Nama Produk" className="w-full border p-2 rounded"
          value={form.name} onChange={handleChange} required />
        <textarea name="description" placeholder="Deskripsi" className="w-full border p-2 rounded"
          value={form.description} onChange={handleChange} required />
        <input name="colors" placeholder="Warna (pisahkan koma, contoh: Merah,Biru)"
          className="w-full border p-2 rounded" value={form.colors} onChange={handleChange} />
        <input name="sizes" placeholder="Ukuran (contoh: S,M,L)" className="w-full border p-2 rounded"
          value={form.sizes} onChange={handleChange} />
        <input name="stock" type="number" placeholder="Stok per kombinasi" className="w-full border p-2 rounded"
          value={form.stock} onChange={handleChange} required />
        <input name="skuPrefix" placeholder="Prefix SKU (contoh: KEM01)" className="w-full border p-2 rounded"
          value={form.skuPrefix} onChange={handleChange} required />
        <button className="bg-yellow-600 text-white py-2 px-4 rounded w-full">Simpan Perubahan</button>
      </form>
    </div>
  );
}
