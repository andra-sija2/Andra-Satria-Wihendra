import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../api/axios';
import { useAuth } from '../auth/AuthContext';

export default function ProductPage() {
  const { id: merchantId } = useParams();
  const { token } = useAuth();
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const res = await api.get(`/products/${merchantId}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        setProducts(res.data);
      } catch (err) {
        console.error(err);
      }
    };
    fetchProducts();
  }, [merchantId, token]);

  return (
    <div className="max-w-4xl mx-auto mt-10">
      <h2 className="text-2xl font-bold mb-4">Produk Merchant</h2>
      
      {/* Tombol untuk menambah produk */}
      <Link to={`/merchant/${merchantId}/products/add`} className="bg-blue-600 text-white px-4 py-2 rounded inline-block mb-4">
        Tambah Produk
      </Link>

      {/* Menampilkan daftar produk */}
      {products.length === 0 ? (
        <p>Tidak ada produk di toko ini.</p>
      ) : (
        <ul className="space-y-4">
          {products.map((product) => (
            <li key={product.id} className="border p-4 rounded shadow">
              <div className="flex justify-between">
                <div>
                  <h3 className="text-lg font-semibold">{product.name}</h3>
                  <p>{product.description}</p>
                </div>
                {/* Tombol Edit */}
                <Link to={`/merchant/${merchantId}/products/edit/${product.id}`} className="bg-yellow-500 text-white px-4 py-2 rounded">
                  Edit Produk
                </Link>
              </div>
              
              {/* Menampilkan variasi produk */}
              <div className="mt-4">
                <h4 className="font-semibold">Variasi:</h4>
                {product.variants.length === 0 ? (
                  <p className="text-sm italic">Tidak ada variasi</p>
                ) : (
                  <ul className="list-disc pl-6">
                    {product.variants.map((variant) => (
                      <li key={variant.id} className="text-sm">
                        {variant.color || '-'} / {variant.size || '-'} - Stok: {variant.stock}, SKU: {variant.sku}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
