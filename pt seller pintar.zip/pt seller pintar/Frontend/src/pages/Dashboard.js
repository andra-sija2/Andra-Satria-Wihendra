import { useEffect, useState } from 'react';
import api from '../api/axios';
import { useAuth } from '../auth/AuthContext';
import { Link } from 'react-router-dom';

export default function Dashboard() {
  const { token } = useAuth();
  const [merchants, setMerchants] = useState([]);

  useEffect(() => {
    const fetchMerchants = async () => {
      try {
        const res = await api.get('/merchants', {
          headers: { Authorization: `Bearer ${token}` },
        });
        setMerchants(res.data);
      } catch (err) {
        console.error(err);
      }
    };
    fetchMerchants();
  }, [token]);

  return (
    <div className="max-w-4xl mx-auto mt-10">
      <h2 className="text-2xl font-bold mb-4">Daftar Merchant</h2>
      <ul className="space-y-2">
        {merchants.map((merchant) => (
          <li key={merchant.id} className="border p-4 rounded shadow">
            <h3 className="text-lg font-semibold">{merchant.name}</h3>
            <Link to={`/merchant/${merchant.id}/products`} className="text-blue-500 underline text-sm">
              Lihat Produk
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
