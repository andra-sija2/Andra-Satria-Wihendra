import { BrowserRouter, Routes, Route } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import Dashboard from './pages/Dashboard';
import ProductPage from './pages/ProductPage';
import Navbar from './components/Navbar';
import AddProductPage from './pages/AddProductPage';
import EditProductPage from './pages/EditProductPage';



function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/merchant/:id/products" element={<ProductPage />} />
        <Route path="/merchant/:id/products/add" element={<AddProductPage />} />
        <Route path="/merchant/:merchantId/products/edit/:productId" element={<EditProductPage />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
